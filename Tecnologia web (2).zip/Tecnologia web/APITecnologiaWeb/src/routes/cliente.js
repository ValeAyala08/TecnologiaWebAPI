const express = require("express");
const clienteSchema = require("../models/cliente_model");

const router = express.Router();
/*
C - Crear      | POST
R - Leer       | GET
U - Actualizar | PUT 
D - Eliminar   | DELETE 
*/


// Listar clientes
router.get('/listarCliente', (req, res) => {
    clienteSchema
    .find()
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});

//Listar cliente por id
router.get('/listarCliente/:id', (req, res) => {
    const { id } = req.params;
    
    clienteSchema
    .findById(id)
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});


// Actulizaar cliente
router.put('/actualizarCliente/:id', (req, res) => {
   const { id } = req.params;
   const {nombre, email, fecha_creacion, fecha_edicion} = req.body;
   clienteSchema
    .updateOne({ _id: id}, {$set: {nombre, email, fecha_creacion, fecha_edicion}})
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
    res.send("Cliente actualizado")
});

// Eliminar cliente
router.delete('/eliminarCliente/:id', (req, res) => {
    const { id } = req.params;
    clienteSchema
    .remove({ _id_cliente: id})
    .then((data) => res.json(data).status(200))
    .catch((error) => res.json({message: error}));
    res.send("Cliente eliminado")
});


module.exports = router;