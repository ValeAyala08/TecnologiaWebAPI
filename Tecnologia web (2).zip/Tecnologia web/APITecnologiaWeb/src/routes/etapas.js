const express = require("express");
const EtapasSchema = require("../models/etapas_model");

const router = express.Router();
/*
C - Crear      | POST
R - Leer       | GET
U - Actualizar | PUT 
D - Eliminar   | DELETE 
*/

//Crear etapas
router.post('/crearEtapas', (req, res) => {
  const etapas = EtapasSchema(req.body);
  etapas
  .save()
  .then((data)=> res.json(data))
  .catch((error) => res.json({message: error}));
});

// Listar etapas
router.get('/listarEtapas', (req, res) => {
    EtapasSchema
    .find()
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});

//Listar etapas por id
router.get('/listarEtapas/:id', (req, res) => {
    const { id } = req.params;
    EtapasSchema
    .findById(id)
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});


// Actulizaar etapas
router.put('/actualizarEtapas/:id', (req, res) => {
   const { id } = req.params;
   const {nombre, fecha_creacion, fecha_actualizacion} = req.body;
   EtapasSchema
    .updateOne({ _id: id}, {$set: {nombre, fecha_creacion, fecha_actualizacion} })
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
    res.send("Etapas actualizadas")
});

// Eliminar etapas
router.delete('/eliminarEtapas/:id', (req, res) => {
    const { id } = req.params;
    EtapasSchema
    .remove({ _id: id})
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
    res.send("Etapas eliminado")
});


module.exports = router;