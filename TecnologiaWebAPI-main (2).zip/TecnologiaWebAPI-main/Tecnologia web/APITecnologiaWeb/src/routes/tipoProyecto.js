const express = require("express");
const tipoProyectoSchema = require("../models/tipoProyecto_model");

const router = express.Router();
/*
C - Crear      | POST
R - Leer       | GET
U - Actualizar | PUT 
D - Eliminar   | DELETE 
*/

//Crear tipoProyecto
router.post('/crearTipoProyecto', (req, res) => {
  const tipoProyecto = tipoProyectoSchema(req.body);
  tipoProyecto
  .save()
  .then((data) => res.json(data))
  .catch((error) => res.json({message: error}));
});

// Listar tipoProyectos
router.get('/listarTipoProyecto', (req, res) => {
    tipoProyectoSchema
    .find()
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});

//Listar tipoProyecto por id
router.get('/listarTipoProyecto/:id', (req, res) => {
    const { id } = req.params;
    tipoProyectoSchema
    .findById(id)
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});

// Actulizaar tipoProyecto
router.put('/actualizarTipoProyecto/:id', (req, res) => {
   const { id } = req.params;
   const {nombre, fecha_creacion, fecha_edicion} = req.body;
   tipoProyectoSchema
    .updateOne({ _id: id}, {$set: {nombre, fecha_creacion, fecha_edicion} })
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
    res.send("Tipo de proyecto actualizado")
});

// Eliminar tipoProyecto
router.delete('/eliminarTipoProyecto/:id', (req, res) => {
    const { id } = req.params;
    tipoProyectoSchema
    .remove({ _id: id})
    .then((data) => res.json)
    .catch((error) => res.json({message: error}));
    res.send("Tipo de proyecto eliminado")
});


module.exports = router;