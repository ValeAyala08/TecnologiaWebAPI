const { Console } = require('console');
const express = require('express');
const mongoose = require ("mongoose");
require ("dotenv").config();

const clienteRoutes = require("./routes/cliente");
const etapasRoutes = require("./routes/etapas");
const proyectoRoutes = require("./routes/proyecto");
const tipoProyectoRoutes = require("./routes/tipoProyecto");
const universidadRoutes = require("./routes/universidad");


const app = express();
const port =process.env.PORT || 9003;

// middleware
app.use(express.json());
app.use('/api', clienteRoutes);
app.use('/api', etapasRoutes);
app.use('/api', proyectoRoutes);
app.use('/api', tipoProyectoRoutes);
app.use('/api', universidadRoutes);


// router
app.get("/", (req, res) => {
    res.send("Bienvenido a la API");
});
/*
app.get("/:id", (req, res) =>{

});
app.post("/", (req, res) =>{
    
});
app.put("/", (req, res) =>{
    
});
app.delete("/", (req, res) =>{
    
});
*/
//mongodb connection
mongoose.connect(process.env.MONGODB_URI)
.then(() => console.log('connected to MongoDB Atlas'))
.catch((error) => console.error(error));

app.listen(port, () => console.log('server listenig on port', port));

